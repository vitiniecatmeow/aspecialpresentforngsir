# vitinie's playlist
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Welcome to Vitinie's Playlist</h1>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="letter.html">Letter to Ng Sir</a></li>
                <li><a href="playlist.html">Playlist</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>我</h2>
        <body>一啲我聽完好有共鳴嘅歌</body>
        <ul id="song-list">
            <li>Baby Don’t Cut - Bmike</li>
            <li>I Scare Myself - Beth Crowley</li>
            <li>teenage dream - Olivia Rodrigo</li>
            <li>To My Parents - Anna Clendening</li>
            <li>If Depression Gets the Best of Me - Zevia</li>
            <li>PTSD - Boyz Reborn</li>
            <li>哭泣健康指南 - gin lee</li>
            <li>勇者鬥惡言 - Mischa Ip</li>
            <li>醫生我無病 - Pong Nan</li>
            <li>旁觀有罪 - 陳蕾</li>
            <li>以正義之名 - 陳蕾</li>
            <li>神的不在場證明 - 陳蕾</li>
            <li>荒島之幻想 - 陳蕾</li>
            <li>和好 - 鄧小巧</li>
            <li>原罪 - 鄧小巧</li>
            <li>可惜你是個人 - 鄧小巧</li>
            <li>無窮 - per se</li>
            <li>所有遺失的東西 - per se</li>
            <li>How to be alive - per se</li>
      </main>
      <main>
        <h2>雜</h2>
        <body>一啲我鍾意但唔知點categorize嘅歌</body>
        <ul id="song-list">
            <li>Song Title 1 - Artist 1</li>
            <li>Song Title 2 - Artist 2</li>
            <li>Song Title 3 - Artist 3</li>
            <li>Song Title 4 - Artist 4</li>
            <li>Song Title 5 - Artist 5</li>
            <li>Song Title 1 - Artist 1</li>
            <li>Song Title 2 - Artist 2</li>
            <li>Song Title 3 - Artist 3</li>
            <li>Song Title 4 - Artist 4</li>
            <li>Song Title 5 - Artist 5</li>
            <li>Song Title 1 - Artist 1</li>
            <li>Song Title 2 - Artist 2</li>
            <li>Song Title 3 - Artist 3</li>
            <li>Song Title 4 - Artist 4</li>
            <li>Song Title 5 - Artist 5</li>
            <!-- Add more songs as needed -->
      </main>
      <main>
        <h2>致</h2>
        <body>一啲送比你嘅歌</body>
        <ul id="song-list">
            <li>天空塌下前 - per se</li>
            <li>波斯雅 - per se</li>
            <li>任我行 - 陳奕迅</li>
            <!-- Add more songs as needed -->
          <main>
            <h3>再見</h3>
            <body>thank you and goodbye!</body>
            <ul id="song-list">
                <li>瑪麗晚安了 - 林家謙 & Yoga Lin</li>
                <li>我想和你好好的 - 陳蕾</li>
                <li>記得 - 林家謙</li>
                <li>某種老朋友 - 林家謙</li>
                <li>變一個發明了Encore - 林家謙</li>
                <li>All We Have Is Now - 林家謙 & 方皓玟</li>
                <li>只記住你 - 鄧小巧</li>
                <li>free fallin’ - 林家謙</li>
                <li>勿念 - yoyo sham</li>
                <li>在生 - per se</li>                
                <li>閃念 - per se</li>
                <li>I was yesterday - per se</li>
                <li>記憶之流 - per se</li>
                <li>不日之約 - per se</li>
                <li>see you tomorrow - per se</li>                
                <li>我們的故事未完...待續 - per se</li>
                <li>The Envelope - per se</li>
                <li>make this moment last - San Holo</li>
                <li>將快樂這刻蔓延(snap it) - Jamie Cheung</li>
                <!-- Add more songs as needed -->
          </main>
          <main>
          <h3>得到</h3>
          <body>一啲我係同你嘅consultation sessions得到嘅insight或者value</body>
          <ul id="song-list">
              <li>有你聽我的故事 - 林家謙</li>
              <li>The End of Night - 鄧紫棋</li>
              <li>念 - 陳蕾</li>
              <li>求救的勇氣 - 陳蕾</li>
              <li>救命歌 - 鄭欣宜</li>              
              <li>世界對我們 - 林家謙</li>
              <li>不藥而癒 - 鄧小巧</li>
              <li>剎那的烏托邦 - yoyo sham</li>
              <li>通心術 - per se</li>
              <li>慶祝無意義 - per se</li>              
              <li>杜松樹之鳥 - per se</li>
              <li>在你失去色彩之前請多多指教 - per se</li>
              <li>因愛而來 - Dear Jane</li>
              <li>I’m Still Here - Kate Winton</li>
              <li>Against the Wind - 鄧紫棋</li>
              <!-- Add more songs as needed -->
          </main>
        </main>
        <main>
        <h2>大家</h2>
        <body>一啲送比你之餘亦都送比自己嘅歌</body>
        <ul id="song-list">
            <li>擇善固執 - 鄧小巧</li>
            <li>Shall We Talk - 陳奕迅</li>
            <li>世界與你無關 - 陳蕾</li>
            <li>你快樂嗎 - 陳蕾</li>
            <li>青年危機 - 陳蕾</li>
            <li>娛樂人生 - 陳蕾</li>
            <li>神奇的糊塗魔藥 - 林家謙</li>
            <li>想創 - 林家謙(Summer blues)</li>
            <li>其實痛是你的想像 - 鄧小巧</li>
            <li>兩種語言 - 鄧小巧</li>
            <li>沒明日的恐懼 - C AllStar</li>
            <li>just carry on - 林家謙</li>
            <li>聽風 - 林家謙</li>
            <li>瀟灑 - 鄧小巧</li>
            <li>風的形狀 - yoyo sham</li>
            <li>無常家 - yoyo sham</li>
            <li>I Always Do - yoyo sham</li>
            <li>孤獨之塔 - per se</li>
            <li>粉碎糖果屋 - per se</li>
            <li>鬥快 - per se</li>
            <li>Branches - per se</li>
            <li>聖馬力諾之心 - Dear Jane</li>
            <li>多謝你自己 - Dear Jane</li>
            <!-- Add more songs as needed -->
        </main>
        <main>
        <h2>希望</h2>
        <body>多謝你讓我見到希望！</body>
        <ul id="song-list">
            <li>天空有岸 - 雷同二友</li>
            <liThe Sky - 鄧紫棋</li>
            <li>我心中尚未崩壞的部分 - 黃妍</li>
            <li>當我迷失時聽著的歌 - 陳蕾</li>
            <li>相信一切是最好的安排 - 陳蕾</li>
            <li>熒光 - 陳蕾</li>
            <li>致明日的舞 - </li>
            <li>林中鳥 - 林欣彤</li>
            <li>也許沒有未來神 - per se</li>
            <li>天光前 - 黃妍</li>
            <!-- Add more songs as needed -->
        </main>
        </ul>
        <p>Feel free to listen and enjoy!</p>
    </main>
    <footer>
        <p>&copy; Vitinie's Playlist</p>
    </footer>
</body>
</html>
