# A Letter to Ng Sir
<body>
    <h3>「因吾，曾被聽見」| "Because You Listened"</h3>
    <p>致我生命中的救贖 — 吳sir,</p>
    <p>由於我自己就唔係啲好artistic嘅人，所以整唔到啲咩紀念品(?)或者(叫做)禮物(?)比你啦哈哈, that's why我打算送首playlist比你，裏面係一啲我鍾意或者每次聽到都會令我唸起你嘅歌，我得閒亦都會update下，而你得閒或者感覺想聽個陣都可以聽下（๑⃙⃘ˊ꒳​ˋ๑⃙⃘）
    <br>我幫個playlist改左個名叫「因吾，曾被聽見」 "Because You Listened", 意味住自己對你嘅感激，感恩你呢四年以嚟嘅聆聽，讓我可以一步一步變得更好，當中用左「吾」字，嚟個字同你嘅姓氏同音，而係文言文當中亦都係「我」嘅意思，代表住我地嘅嚟段therapeutic relationship, 雖然今日嚟到尾聲，但嚟個世界的確唔會有人永遠都陪住自己，身邊嘅人總有一日會離開我，但願我地彼此都會記得個啲係診症室裏面嘅美好時光、我地嘅笑聲、眼淚... 雖然離別係痛苦的，但我相信我地有緣一定會再見的，多謝你，我親愛嘅精神科護士，願你一直安好！all the best and goodbye!
    <br>祝(你)
    <br>在亂流下平安</p>
<footer>
    <p>Best wishes, 
        <br>Fok Man Ying Vitinie</p>
</footer>
</body>
 <footer>
        <p>&copy; Vitinie's Playlist</p>
</footer>
</html>
