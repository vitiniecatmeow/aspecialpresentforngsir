# A Special Present for Ng Sir
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    Dear Ng Sir,
    <br>This is a special playlist for you. In this playlist, there's a collection of my favourite songs and songs that made me think of you. Hope you would like it! Thank you for your accompaniment in these few years, all the best and goodbye!
    <br>Best Wishes,
    <br>Fok Man Ying Vitinie
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h2>Welcome to My Playlist</h2>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="lettertongsir.html">Letter to Ng Sir</a></li>
                <li><a href="vitinieplaylist.html">Welcome to Vitinie's Playlist</a></li>
            </ul>
        </nav>
    </header>
    <footer>
        <p>&copy; Vitinie's Playlist</p>
    </footer>
</body>
</html>
